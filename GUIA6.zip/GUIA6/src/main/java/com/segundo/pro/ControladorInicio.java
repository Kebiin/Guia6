
package com.segundo.pro;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.beans.factory.annotation.Value;
import com.segundo.modelo.Usuario;
/**
 *
 * @author family
 */



@Controller
@Slf4j
public class ControladorInicio {
    @Value("${index.mensaje}")
    String dato;
    @GetMapping("/")
    public String inicio(Model modelo){
        String mensaje = "saludos my friends";
        modelo.addAttribute("mensaje", mensaje);
        modelo.addAttribute("dato", dato);
        Usuario u = new Usuario();
        u.setCedula("0123");
        u.setClave("abcd");
        u.setNombre("alaba y embape");
        u.setEmail("alaba.com");
        modelo.addAttribute("usuario", u);
        log.info("Ejecutando el controlador de");
        return "index";
    }
}
