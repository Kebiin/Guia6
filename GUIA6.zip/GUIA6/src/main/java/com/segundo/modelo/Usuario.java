
package com.segundo.modelo;

import lombok.Data;

/**
 *
 * @author family
 */
@Data
public class Usuario {
    private String cedula;
    private String nombre;
    private String email;
    private String clave;
}
